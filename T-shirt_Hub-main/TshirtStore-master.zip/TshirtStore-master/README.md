# TshirtStore
- Merchandise selling e-commerce website with PAYPAL payment gateway integration.
- Created an admin panel for dynamic handling and rendering of content and events.
- Implemented JWT authentication
